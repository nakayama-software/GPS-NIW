<?php
// config.php

$host = 'mysqldb.nakayamairon.com';
$user ='ncs85283278';
$pass = 'CuMdjlWs';
$dbname ='ncs85283278_NIW_GPS';
$charset = 'utf8mb4';

